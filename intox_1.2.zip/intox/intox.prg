Function main()
cls
set color to gr+/r+
set century on
set date british

? "---------------------------------------------------------------------------------"
? "| intox.exe versao 1.2 - 09/10/2026                                             |"
? "| https://github.com/Regional-Entorno-Sul/Intox                                 |"
? "| Regional de saude Entorno Sul                                                 |"
? "| Sintaxe do executavel: intox.exe [--modo]                                     |"
? "| Modos possiveis: --via --circ --evoluc --prescri --automedic --planta --idade |"
? "| Exemplo: intox.exe --via                                                      |"
? "---------------------------------------------------------------------------------"
set color to w+/

cModo := HB_ArgV ( 1 )

if empty( cModo ) = .T.
set color to r+/
? "Erro! Falta o argumento 'modo' no executavel."
? "Fim do programa."
wait
quit
endif

? "Modo:" + alltrim( cModo )

if cModo <> "--via" .and. cModo <> "--circ" .and. cModo <> "--evoluc" .and. cModo <> "--prescri" .and. cModo <> "--automedic" .and. cModo <> "--planta" .and. cModo <> "--idade" 
set color to r+/
? "Erro! O argumento indicado pelo usuario nao existe."
? "Fim do programa."
wait
quit
endif

if file("c:\intox\DBF\iexognet.dbf") = .F.
set color to r+/
? "Erro! O arquivo 'iexognet.dbf.' nao esta presente na subpasta 'DBF'."
? "Fim do programa."
wait
quit
endif

if cModo = "--via"
via()
endif

if cModo = "--circ"
circ()
endif

if cModo = "--evoluc"
evoluc()
endif

if cModo = "--prescri"
prescri()
endif

if cModo = "--automedic"
automedic()
endif

if cModo = "--planta"
planta()
endif

if cModo = "--idade"
idade()
endif

function via()
set color to g+/

? "Copiando arquivos..."
copy file "c:\intox\DBF\iexognet.dbf" to "c:\intox\tmp\iexo_via.dbf"
copy file "c:\intox\model\iexo_via_light.dbf" to "c:\intox\tmp\iexo_via_light.dbf"

? "Filtrando os dados..."
use "c:\intox\tmp\iexo_via.dbf"
do while .not. eof()
replace tp_not with "x" for cs_sexo = "M" .and. ( via_1 = "6" .or. via_1 = "7" )
enddo
close

use "c:\intox\tmp\iexo_via.dbf"
do while .not. eof()
replace tp_not with "x" for cs_sexo = "M" .and. ( via_2 = "6" .or. via_2 = "7" )
enddo
close

use "c:\intox\tmp\iexo_via.dbf"
do while .not. eof()
replace tp_not with "x" for cs_sexo = "M" .and. ( via_3 = "6" .or. via_3 = "7" )
enddo
close

? "Excluindo os registros que nao sao de interesse..."
use "c:\intox\tmp\iexo_via.dbf"
delete for tp_not <> "x"
pack

*campos para o arquivo simplificado (light): nu_notific, tp_not, dt_notific, id_municip, nm_pacient, dt_nasc, cs_sexo, nm_mae_pac, id_mn_resi, via_1, via_2, via_3

? "Transferindo os registros para um arquivo de saida simplificado..."
use "c:\intox\tmp\iexo_via_light.dbf"
append from "c:\intox\tmp\iexo_via.dbf"
close

? "Transferindo o arquivo simplificado para a subpasta apropriada..."
copy file "c:\intox\tmp\iexo_via_light.dbf" to "c:\intox\out\iexo_via_light.dbf"

? "Fim do processo..."

set color to w+/
? "Arquivo final esta em: c:\intox\out\iexo_via_light.dbf"

return

function circ()
set color to g+/

? "Copiando arquivos..."
copy file "c:\intox\DBF\iexognet.dbf" to "c:\intox\tmp\iexo_circunstancia.dbf"
copy file "c:\intox\model\iexo_circ_light.dbf" to "c:\intox\tmp\iexo_circ_light.dbf"

? "Filtrando os dados..."
use "c:\intox\tmp\iexo_circunstancia.dbf"
do while .not. eof()
replace tp_not with "x" for cs_sexo = "M" .and. circunstan = "11"
enddo
close

? "Excluindo os registros que nao sao de interesse..."
use "c:\intox\tmp\iexo_circunstancia.dbf"
delete for tp_not <> "x"
pack

*campos para o arquivo simplificado (light): nu_notific, tp_not, dt_notific, id_municip, nm_pacient, dt_nasc, cs_sexo, nm_mae_pac, id_mn_resi, circunstan

? "Transferindo os registros para um arquivo de saida simplificado..."
use "c:\intox\tmp\iexo_circ_light.dbf"
append from "c:\intox\tmp\iexo_circunstancia.dbf"
close

? "Transferindo o arquivo simplificado para a subpasta apropriada..."
copy file "c:\intox\tmp\iexo_circ_light.dbf" to "c:\intox\out\iexo_circ_light.dbf"

? "Fim do processo..."

set color to w+/
? "Arquivo final esta em: c:\intox\out\iexo_circ_light.dbf"

return

function evoluc()
set color to g+/

? "Copiando arquivos..."
copy file "c:\intox\DBF\iexognet.dbf" to "c:\intox\tmp\iexo_evoluc.dbf"
copy file "c:\intox\model\iexo_evoluc_light.dbf" to "c:\intox\tmp\iexo_evoluc_light.dbf"

? "Filtrando os dados..."
use "c:\intox\tmp\iexo_evoluc.dbf"
do while .not. eof()
replace tp_not with "x" for evolucao = "3" .and. classi_fin <> "1"
enddo
close

? "Excluindo os registros que nao sao de interesse..."
use "c:\intox\tmp\iexo_evoluc.dbf"
delete for tp_not <> "x"
pack

*campos para o arquivo simplificado (light): nu_notific, tp_not, dt_notific, id_municip, nm_pacient, dt_nasc, nm_mae_pac, id_mn_resi, classi_fin, evolucao 

? "Transferindo os registros para um arquivo de saida simplificado..."
use "c:\intox\tmp\iexo_evoluc_light.dbf"
append from "c:\intox\tmp\iexo_evoluc.dbf"
close

? "Transferindo o arquivo simplificado para a subpasta apropriada..."
copy file "c:\intox\tmp\iexo_evoluc_light.dbf" to "c:\intox\out\iexo_evoluc_light.dbf"

? "Fim do processo..."

set color to w+/
? "Arquivo final esta em: c:\intox\out\iexo_evoluc_light.dbf"

return

function prescri()
set color to g+/

? "Copiando arquivos..."
copy file "c:\intox\DBF\iexognet.dbf" to "c:\intox\tmp\iexo_prescri.dbf"
copy file "c:\intox\model\iexo_prescri_light.dbf" to "c:\intox\tmp\iexo_prescri_light.dbf"

? "Filtrando os dados..."
use "c:\intox\tmp\iexo_prescri.dbf"
do while .not. eof()
replace tp_not with "x" for circunstan = "05" .and. ( agente_tox = "02" .or. agente_tox = "03" .or. agente_tox = "04" .or. agente_tox = "05" .or. agente_tox = "06" .or. agente_tox = "07" .or. agente_tox = "09" .or. agente_tox = "10" .or. agente_tox = "11" .or. agente_tox = "12" .or. agente_tox = "13" )
enddo
close

? "Excluindo os registros que nao sao de interesse..."
use "c:\intox\tmp\iexo_prescri.dbf"
delete for tp_not <> "x"
pack

*campos para o arquivo simplificado (light): nu_notific, tp_not, dt_notific, id_municip, nm_pacient, dt_nasc, nm_mae_pac, id_mn_resi, agente_tox, circunstan

? "Transferindo os registros para um arquivo de saida simplificado..."
use "c:\intox\tmp\iexo_prescri_light.dbf"
append from "c:\intox\tmp\iexo_prescri.dbf"
close

? "Transferindo o arquivo simplificado para a subpasta apropriada..."
copy file "c:\intox\tmp\iexo_prescri_light.dbf" to "c:\intox\out\iexo_prescri_light.dbf"

? "Fim do processo..."

set color to w+/
? "Arquivo final esta em: c:\intox\out\iexo_prescri_light.dbf"

return

function automedic()
set color to g+/

? "Copiando arquivos..."
copy file "c:\intox\DBF\iexognet.dbf" to "c:\intox\tmp\iexo_automedic.dbf"
copy file "c:\intox\model\iexo_automedic_light.dbf" to "c:\intox\tmp\iexo_automedic_light.dbf"

? "Filtrando os dados..."
use "c:\intox\tmp\iexo_automedic.dbf"
do while .not. eof()
replace tp_not with "x" for circunstan = "07" .and. ( agente_tox = "02" .or. agente_tox = "03" .or. agente_tox = "04" .or. agente_tox = "05" .or. agente_tox = "06" .or. agente_tox = "07" .or. agente_tox = "09" .or. agente_tox = "10" .or. agente_tox = "11" .or. agente_tox = "13" )
enddo
close

? "Excluindo os registros que nao sao de interesse..."
use "c:\intox\tmp\iexo_automedic.dbf"
delete for tp_not <> "x"
pack

*campos para o arquivo simplificado (light): nu_notific, tp_not, dt_notific, id_municip, nm_pacient, dt_nasc, nm_mae_pac, id_mn_resi, agente_tox, circunstan

? "Transferindo os registros para um arquivo de saida simplificado..."
use "c:\intox\tmp\iexo_automedic_light.dbf"
append from "c:\intox\tmp\iexo_automedic.dbf"
close

? "Transferindo o arquivo simplificado para a subpasta apropriada..."
copy file "c:\intox\tmp\iexo_automedic_light.dbf" to "c:\intox\out\iexo_automedic_light.dbf"

? "Fim do processo..."

set color to w+/
? "Arquivo final esta em: c:\intox\out\iexo_automedic_light.dbf"

return

function planta()
set color to g+/

? "Copiando arquivos..."
copy file "c:\intox\DBF\iexognet.dbf" to "c:\intox\tmp\iexo_planta.dbf"
copy file "c:\intox\model\iexo_planta_light.dbf" to "c:\intox\tmp\iexo_planta_light.dbf"

? "Filtrando os dados..."
use "c:\intox\tmp\iexo_planta.dbf"
do while .not. eof()
replace tp_not with "x" for circunstan = "03" .and. agente_tox = "12"
enddo
close

? "Excluindo os registros que nao sao de interesse..."
use "c:\intox\tmp\iexo_planta.dbf"
delete for tp_not <> "x"
pack

*campos para o arquivo simplificado (light): nu_notific, tp_not, dt_notific, id_municip, nm_pacient, dt_nasc, nm_mae_pac, id_mn_resi, agente_tox, circunstan

? "Transferindo os registros para um arquivo de saida simplificado..."
use "c:\intox\tmp\iexo_planta_light.dbf"
append from "c:\intox\tmp\iexo_planta.dbf"
close

? "Transferindo o arquivo simplificado para a subpasta apropriada..."
copy file "c:\intox\tmp\iexo_planta_light.dbf" to "c:\intox\out\iexo_planta_light.dbf"

? "Fim do processo..."

set color to w+/
? "Arquivo final esta em: c:\intox\out\iexo_planta_light.dbf"

return

function idade()

set color to g+/

? "Copiando arquivos..."
copy file "c:\intox\DBF\iexognet.dbf" to "c:\intox\tmp\iexo_idade.dbf"
copy file "c:\intox\model\iexo_idade_light.dbf" to "c:\intox\tmp\iexo_idade_light.dbf"

? "Filtrando os dados..."
use "c:\intox\tmp\iexo_idade.dbf"
do while .not. eof()
replace tp_not with "x" for nu_idade_n >= 4014
enddo
close

use "c:\intox\tmp\iexo_idade.dbf"
do while .not. eof()
replace id_agravo with "x" for doenca_tra = "1"
enddo
close

? "Excluindo os registros que nao sao de interesse..."
use "c:\intox\tmp\iexo_idade.dbf"
delete for tp_not = "x"
pack
close

use "c:\intox\tmp\iexo_idade.dbf"
delete for id_agravo != "x"
pack
close

*campos para o arquivo simplificado (light): nu_notific, tp_not, dt_notific, id_municip, nm_pacient, dt_nasc, nu_idade_n, nm_mae_pac, id_mn_resi

? "Transferindo os registros para um arquivo de saida simplificado..."
use "c:\intox\tmp\iexo_idade_light.dbf"
append from "c:\intox\tmp\iexo_idade.dbf"
close

? "Transferindo o arquivo simplificado para a subpasta apropriada..."
copy file "c:\intox\tmp\iexo_idade_light.dbf" to "c:\intox\out\iexo_idade_light.dbf"

? "Fim do processo..."

set color to w+/
? "Arquivo final esta em: c:\intox\out\iexo_idade_light.dbf"

return

return nil